import { render, screen } from "@testing-library/react";
import { describe, test, expect } from "vitest";

describe("Gallery page", () => {

    test("renders gallery title", () => {

        render(
            <h1>My Gallery</h1>
        );

        expect(
            screen.getByText(
                "My Gallery"
            )
        ).toBeTruthy();

    });

});