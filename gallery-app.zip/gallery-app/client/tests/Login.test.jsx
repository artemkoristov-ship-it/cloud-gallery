import { render, screen } from "@testing-library/react";
import { describe, test, expect } from "vitest";

describe("Login page", () => {

    test("shows login button", () => {

        render(
            <button>Login</button>
        );

        expect(
            screen.getByText("Login")
        ).toBeTruthy();

    });

});