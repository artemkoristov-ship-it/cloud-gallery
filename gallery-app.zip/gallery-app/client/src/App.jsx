import { useState } from "react";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Gallery from "./pages/Gallery";

function App() {

    const token =
        localStorage.getItem(
            "token"
        );

    const [isLogin,
        setIsLogin] =
        useState(true);

    if (token) {

        return <Gallery />;

    }

    return (

        <div>

            {isLogin
                ? <Login />
                : <Register />
            }

            <button
                onClick={() =>
                    setIsLogin(
                        !isLogin
                    )
                }
            >
                {isLogin
                    ? "Create account"
                    : "Back to login"}
            </button>

        </div>

    );
}

export default App;