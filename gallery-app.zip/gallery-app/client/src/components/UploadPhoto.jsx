import { useState } from "react";
import API from "../services/api";

function UploadPhoto({ refreshPhotos }) {

    const [title, setTitle] =
        useState("");

    const [file, setFile] =
        useState(null);

    const uploadPhoto =
        async () => {

            try {

                const token =
                    localStorage.getItem(
                        "token"
                    );

                const formData =
                    new FormData();

                formData.append(
                    "title",
                    title
                );

                formData.append(
                    "image",
                    file
                );

                await API.post(
                    "/photos/upload",
                    formData,
                    {
                        headers: {
                            Authorization:
                                `Bearer ${token}`,
                        },
                    }
                );

                setTitle("");
                setFile(null);

                refreshPhotos();

            } catch (error) {

                console.log(error);

            }
        };

    return (

        <div className="upload-box">

            <h3>Upload photo</h3>

            <input
                type="text"
                placeholder="Photo title"
                value={title}
                onChange={(e) =>
                    setTitle(
                        e.target.value
                    )
                }
            />

            <input
                type="file"
                onChange={(e) =>
                    setFile(
                        e.target.files[0]
                    )
                }
            />

            <button
                onClick={uploadPhoto}
            >
                Upload
            </button>

        </div>
    );
}

export default UploadPhoto;