import { useState } from "react";
import API from "../services/api";

function Upload() {

    const [title, setTitle] = useState("");

    const [image, setImage] = useState(null);

    const handleSubmit = async (e) => {

        e.preventDefault();

        const formData = new FormData();

        formData.append("title", title);

        formData.append("image", image);

        try {

            const token = localStorage.getItem("token");

            await API.post(
                "/photos/upload",
                formData,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            );

            alert("Фото завантажено");

        } catch (error) {

            console.log(error);

        }
    };

    return (
        <div>

            <h2>Upload Photo</h2>

            <form onSubmit={handleSubmit}>

                <input
                    type="text"
                    placeholder="Title"
                    onChange={(e) =>
                        setTitle(e.target.value)
                    }
                />

                <br />

                <input
                    type="file"
                    onChange={(e) =>
                        setImage(e.target.files[0])
                    }
                />

                <br />

                <button type="submit">
                    Upload
                </button>

            </form>

        </div>
    );
}

export default Upload;