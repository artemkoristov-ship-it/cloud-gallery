import { useEffect, useState } from "react";
import API from "../services/api";
import UploadPhoto from "../components/UploadPhoto";

function Gallery() {

    const [photos, setPhotos] =
        useState([]);

    const fetchPhotos =
        async () => {

            try {

                const token =
                    localStorage.getItem(
                        "token"
                    );

                const res =
                    await API.get(
                        "/photos",
                        {
                            headers: {
                                Authorization:
                                    `Bearer ${token}`,
                            },
                        }
                    );

                setPhotos(res.data);

            } catch (error) {

                console.log(error);

            }
        };

    useEffect(() => {

        fetchPhotos();

    }, []);

    const deletePhoto =
        async (id) => {

            try {

                const token =
                    localStorage.getItem(
                        "token"
                    );

                await API.delete(
                    `/photos/${id}`,
                    {
                        headers: {
                            Authorization:
                                `Bearer ${token}`,
                        },
                    }
                );

                fetchPhotos();

            } catch (error) {

                console.log(error);

            }
        };

    return (

        <div className="gallery-page">

            <div className="header">

                <h1>
                    My Gallery
                </h1>

                <button
                    className="logout-btn"
                    onClick={() => {

                        localStorage.removeItem(
                            "token"
                        );

                        window.location.reload();

                    }}
                >
                    Logout
                </button>

            </div>

            <UploadPhoto
                refreshPhotos={
                    fetchPhotos
                }
            />

            <div className="gallery-grid">

                {photos.map((photo) => (

                    <div
                        className="photo-card"
                        key={photo._id}
                    >

                        <img
                            src={`http://localhost:5000/${photo.imageUrl}`}
                            alt=""
                        />

                        <h4>
                            {photo.title}
                        </h4>

                        <button
                            onClick={() =>
                                deletePhoto(
                                    photo._id
                                )
                            }
                        >
                            Delete
                        </button>

                    </div>

                ))}

            </div>

        </div>
    );
}

export default Gallery;