import { useState } from "react";
import API from "../services/api";

function Login() {

    const [email, setEmail] =
        useState("");

    const [password, setPassword] =
        useState("");

    const handleLogin =
        async () => {

            try {

                const res =
                    await API.post(
                        "/auth/login",
                        {
                            email,
                            password,
                        }
                    );

                localStorage.setItem(
                    "token",
                    res.data.token
                );

                window.location.reload();

            } catch {

                alert(
                    "Невірний логін або пароль"
                );

            }
        };

    return (

        <div className="auth-container">

            <h2>Login</h2>

            <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) =>
                    setEmail(e.target.value)
                }
            />

            <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) =>
                    setPassword(e.target.value)
                }
            />

            <button
                onClick={handleLogin}
            >
                Login
            </button>

        </div>
    );
}

export default Login;