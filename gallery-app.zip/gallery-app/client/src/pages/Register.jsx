import { useState } from "react";
import API from "../services/api";

function Register() {

    const [username, setUsername] =
        useState("");

    const [email, setEmail] =
        useState("");

    const [password, setPassword] =
        useState("");

    const handleRegister =
        async () => {

            try {

                await API.post(
                    "/auth/register",
                    {
                        username,
                        email,
                        password,
                    }
                );

                alert(
                    "Реєстрація успішна"
                );

            } catch (error) {

                alert(
                    error.response?.data?.message
                );

            }
        };

    return (

        <div className="auth-container">

            <h2>Register</h2>

            <input
                type="text"
                placeholder="Username"
                onChange={(e) =>
                    setUsername(
                        e.target.value
                    )
                }
            />

            <input
                type="email"
                placeholder="Email"
                onChange={(e) =>
                    setEmail(
                        e.target.value
                    )
                }
            />

            <input
                type="password"
                placeholder="Password"
                onChange={(e) =>
                    setPassword(
                        e.target.value
                    )
                }
            />

            <button
                onClick={handleRegister}
            >
                Register
            </button>

        </div>
    );
}

export default Register;