const jwt = require("jsonwebtoken");
const User = require("../models/User");

const protect = async (req, res, next) => {

    let token;

    // перевірка headers
    if (
        req.headers.authorization &&
        req.headers.authorization.startsWith("Bearer")
    ) {

        try {

            // отримання token
            token = req.headers.authorization.split(" ")[1];

            // декодування token
            const decoded = jwt.verify(
                token,
                process.env.JWT_SECRET
            );

            // пошук користувача
            req.user = await User.findById(decoded.id).select("-password");

            next();

        } catch (error) {

            return res.status(401).json({
                message: "Не авторизовано",
            });

        }

    }

    if (!token) {

        return res.status(401).json({
            message: "Token не знайдено",
        });

    }
};

module.exports = {
    protect,
};