const express = require("express");

const router = express.Router();

const {
    uploadPhoto,
    getUserPhotos,
    deletePhoto,
} = require("../controllers/photoController");

const {
    protect,
} = require("../middleware/authMiddleware");

const upload = require("../middleware/uploadMiddleware");

router.post(
    "/upload",
    protect,
    upload.single("image"),
    uploadPhoto
);

router.get("/", protect, getUserPhotos);
router.delete(
    "/:id",
    protect,
    deletePhoto
);
module.exports = router;