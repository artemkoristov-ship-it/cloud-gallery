const request = require("supertest");
const app = require("../app");

describe("Auth API", () => {

    test("POST /api/auth/login", async () => {

        const response = await request(app)
            .post("/api/auth/login")
            .send({
                email: "admin@gmail.com",
                password: "123456"
            });

        expect(response.statusCode).toBe(200);

        expect(response.body).toHaveProperty("token");

    });

});
