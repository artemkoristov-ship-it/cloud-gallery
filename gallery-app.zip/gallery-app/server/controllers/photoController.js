const Photo = require("../models/Photo");

const uploadPhoto = async (req, res) => {

    try {

        const photo = await Photo.create({

            title: req.body.title,

            imageUrl: req.file.path,

            user: req.user._id,

        });

        res.status(201).json(photo);

    } catch (error) {

        res.status(500).json({
            message: error.message,
        });

    }
};

const getUserPhotos = async (req, res) => {

    try {

        const photos = await Photo.find({
            user: req.user._id,
        });

        res.json(photos);

    } catch (error) {

        res.status(500).json({
            message: error.message,
        });

    }
};
const deletePhoto = async (req, res) => {

    try {

        const photo = await Photo.findById(
            req.params.id
        );

        if (!photo) {
            return res.status(404).json({
                message: "Фото не знайдено",
            });
        }

        // перевірка власника
        if (
            photo.user.toString() !==
            req.user._id.toString()
        ) {
            return res.status(401).json({
                message: "Немає доступу",
            });
        }

        await photo.deleteOne();

        res.json({
            message: "Фото видалено",
        });

    } catch (error) {

        res.status(500).json({
            message: error.message,
        });

    }
};
module.exports = {
    uploadPhoto,
    getUserPhotos,
    deletePhoto,
};
