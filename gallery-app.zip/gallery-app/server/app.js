const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");

const connectDB = require("./config/db");

dotenv.config();

connectDB();

const authRoutes = require("./routes/authRoutes");

const app = express();

app.use(cors());

app.use(express.json());
const photoRoutes = require("./routes/photoRoutes");
app.use("/api/photos", photoRoutes);
app.use("/uploads", express.static("uploads"));

app.use("/api/auth", authRoutes);

app.get("/", (req, res) => {
    res.send("Gallery API працює");
});

const PORT = process.env.PORT || 5000;

const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`Сервер запущено на порту ${PORT}`);
});

module.exports = app;
;